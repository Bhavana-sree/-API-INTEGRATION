🌦️ Weather App
A simple Flask-based Weather App that fetches and displays real-time weather data from the OpenWeatherMap API. Users can enter a city name to get the current temperature, weather condition, and an icon representing the weather status.

📖 Project Instructions
1️⃣ Clone the Repository
bash
Copy
Edit
git clone https://github.com/your-username/weather_app.git
cd weather_app
2️⃣ Create a Virtual Environment (Optional, Recommended)
bash
Copy
Edit
python -m venv venv
source venv/bin/activate  # macOS/Linux
venv\Scripts\activate     # Windows
3️⃣ Install Required Dependencies
bash
Copy
Edit
pip install -r requirements.txt
4️⃣ Get an OpenWeatherMap API Key
Go to OpenWeatherMap and sign up.
Generate a free API key.
Create a .env file in the project root and add:
ini
Copy
Edit
OPENWEATHER_API_KEY=your_api_key_here
5️⃣ Run the Flask Application
bash
Copy
Edit
python app.py
6️⃣ Open the App in Your Browser
Visit: http://127.0.0.1:5000/